#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";

function usage() {
  console.error("Usage: node tools/extract-pdf-text.mjs <input.pdf> [output.txt]");
  process.exit(1);
}

function cleanHex(hex) {
  return (hex || "").replace(/[^0-9a-f]/gi, "");
}

function decodeUnicodeHex(hex) {
  const cleaned = cleanHex(hex);
  if (!cleaned) return "";
  const bytes = Buffer.from(cleaned, "hex");

  const candidates = [bytes.toString("latin1")];

  if (bytes.length % 2 === 0) {
    try {
      const swapped = Buffer.allocUnsafe(bytes.length);
      for (let index = 0; index < bytes.length; index += 2) {
        swapped[index] = bytes[index + 1];
        swapped[index + 1] = bytes[index];
      }
      candidates.push(swapped.toString("utf16le"));
    } catch {}
  }

  return candidates
    .map((value) => ({ value, score: scoreTextCandidate(value) }))
    .sort((left, right) => right.score - left.score)[0].value;
}

function scoreTextCandidate(text) {
  let score = 0;

  for (const char of text) {
    const code = char.charCodeAt(0);
    if (code === 0) {
      score -= 5;
      continue;
    }
    if ((code >= 32 && code <= 126) || char === "\n" || char === "\r" || char === "\t") {
      score += 2;
      continue;
    }
    if ((code >= 160 && code <= 255) || /\p{L}|\p{N}/u.test(char)) {
      score += 1;
      continue;
    }
    score -= 2;
  }

  return score;
}

function normalizeWhitespace(text) {
  return text
    .replace(/\u0000/g, "")
    .replace(/\r/g, "\n")
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function parseObjects(buffer) {
  const source = buffer.toString("latin1");
  const objects = new Map();
  const objectPattern = /(\d+)\s+(\d+)\s+obj([\s\S]*?)endobj/g;

  for (const match of source.matchAll(objectPattern)) {
    const id = Number(match[1]);
    const fullText = match[0];
    const body = match[3];
    const start = match.index ?? 0;
    const end = start + fullText.length;
    let stream = null;
    let dict = body;

    const streamIndex = body.indexOf("stream");
    if (streamIndex !== -1) {
      dict = body.slice(0, streamIndex);

      let streamStart = start + fullText.indexOf("stream") + 6;
      if (source[streamStart] === "\r" && source[streamStart + 1] === "\n") {
        streamStart += 2;
      } else if (source[streamStart] === "\n") {
        streamStart += 1;
      }

      const localEnd = fullText.indexOf("endstream");
      if (localEnd !== -1) {
        const streamEnd = start + localEnd;
        stream = buffer.slice(streamStart, streamEnd);
      }
    }

    objects.set(id, { id, dict, stream, body, start, end });
  }

  return objects;
}

function maybeInflate(object) {
  if (!object?.stream) return null;
  if (/FlateDecode/.test(object.dict)) {
    try {
      return zlib.inflateSync(object.stream);
    } catch {
      return null;
    }
  }
  return object.stream;
}

function parseArrayHexStrings(content) {
  const parts = [];
  const hexPattern = /<([0-9a-fA-F]+)>/g;
  for (const match of content.matchAll(hexPattern)) {
    parts.push(match[1]);
  }
  const literalPattern = /\(([^()]*)\)/g;
  for (const match of content.matchAll(literalPattern)) {
    parts.push(Buffer.from(match[1], "latin1").toString("hex"));
  }
  return parts;
}

function parseToUnicodeMap(cmapText) {
  const map = new Map();
  const lines = cmapText.split(/\r?\n/);
  let index = 0;

  while (index < lines.length) {
    const line = lines[index].trim();
    const bfcharMatch = line.match(/^(\d+)\s+beginbfchar$/);
    const bfrangeMatch = line.match(/^(\d+)\s+beginbfrange$/);

    if (bfcharMatch) {
      const count = Number(bfcharMatch[1]);
      for (let i = 0; i < count; i += 1) {
        const entry = (lines[++index] || "").trim();
        const match = entry.match(/^<([0-9A-Fa-f]+)>\s+<([0-9A-Fa-f]+)>$/);
        if (match) {
          map.set(parseInt(match[1], 16), decodeUnicodeHex(match[2]));
        }
      }
    } else if (bfrangeMatch) {
      const count = Number(bfrangeMatch[1]);
      for (let i = 0; i < count; i += 1) {
        const entry = (lines[++index] || "").trim();
        const simple = entry.match(
          /^<([0-9A-Fa-f]+)>\s+<([0-9A-Fa-f]+)>\s+<([0-9A-Fa-f]+)>$/,
        );
        const array = entry.match(
          /^<([0-9A-Fa-f]+)>\s+<([0-9A-Fa-f]+)>\s+\[(.+)\]$/,
        );

        if (simple) {
          const start = parseInt(simple[1], 16);
          const end = parseInt(simple[2], 16);
          let target = parseInt(simple[3], 16);
          for (let code = start; code <= end; code += 1) {
            const width = simple[3].length;
            map.set(code, decodeUnicodeHex(target.toString(16).padStart(width, "0")));
            target += 1;
          }
        } else if (array) {
          const start = parseInt(array[1], 16);
          const end = parseInt(array[2], 16);
          const values = [...array[3].matchAll(/<([0-9A-Fa-f]+)>/g)].map((m) => m[1]);
          for (let code = start; code <= end; code += 1) {
            const value = values[code - start];
            if (value) map.set(code, decodeUnicodeHex(value));
          }
        }
      }
    }

    index += 1;
  }

  return map;
}

function buildFontMaps(objects) {
  const resourceFonts = new Map();
  const fontMaps = new Map();

  for (const object of objects.values()) {
    const fontBlock = object.dict.match(/\/Font\s*<<([\s\S]*?)>>/);
    if (!fontBlock) continue;

    for (const match of fontBlock[1].matchAll(/\/([A-Za-z0-9_]+)\s+(\d+)\s+0\s+R/g)) {
      resourceFonts.set(match[1], Number(match[2]));
    }
  }

  for (const [resourceName, fontObjectId] of resourceFonts.entries()) {
    const fontObject = objects.get(fontObjectId);
    if (!fontObject) continue;

    const refMatch = fontObject.dict.match(/\/ToUnicode\s+(\d+)\s+0\s+R/);
    if (!refMatch) continue;

    const cmapObject = objects.get(Number(refMatch[1]));
    const cmapBuffer = maybeInflate(cmapObject);
    if (!cmapBuffer) continue;

    const cmapText = cmapBuffer.toString("latin1");
    fontMaps.set(resourceName, parseToUnicodeMap(cmapText));
  }

  return fontMaps;
}

function decodeGlyphHex(hex, fontMap) {
  const cleaned = cleanHex(hex);
  if (!cleaned) return "";

  const parts = [];
  const width = 4;
  for (let index = 0; index < cleaned.length; index += width) {
    const chunk = cleaned.slice(index, index + width);
    if (!chunk) continue;
    const code = parseInt(chunk, 16);
    const mapped = fontMap?.get(code);
    if (mapped) {
      parts.push(mapped);
    } else {
      parts.push(decodeUnicodeHex(chunk));
    }
  }

  return parts.join("");
}

function extractTextFromStream(streamText, fontMaps) {
  let currentFont = null;
  const out = [];
  const tokenPattern =
    /\/([A-Za-z0-9_]+)\s+[-+]?\d*\.?\d+\s+Tf|<([0-9A-Fa-f]+)>\s*Tj|\[(.*?)\]\s*TJ/gms;

  for (const match of streamText.matchAll(tokenPattern)) {
    if (match[1]) {
      currentFont = match[1];
      continue;
    }

    const fontMap = fontMaps.get(currentFont);

    if (match[2]) {
      const value = decodeGlyphHex(match[2], fontMap);
      if (value) out.push(value);
      continue;
    }

    if (match[3]) {
      const pieces = parseArrayHexStrings(match[3])
        .map((piece) => decodeGlyphHex(piece, fontMap))
        .filter(Boolean);
      if (pieces.length) out.push(pieces.join(""));
    }
  }

  return out.join("\n");
}

function extractPdfText(filePath) {
  const buffer = fs.readFileSync(filePath);
  const objects = parseObjects(buffer);
  const fontMaps = buildFontMaps(objects);
  const chunks = [];

  for (const object of objects.values()) {
    const stream = maybeInflate(object);
    if (!stream) continue;

    const streamText = stream.toString("latin1");
    if (!/(Tj|TJ|Tf)/.test(streamText)) continue;

    const text = extractTextFromStream(streamText, fontMaps);
    if (text) chunks.push(text);
  }

  return normalizeWhitespace(chunks.join("\n\n"));
}

const [, , inputPath, outputPath] = process.argv;
if (!inputPath) usage();

const absoluteInput = path.resolve(inputPath);
const text = extractPdfText(absoluteInput);

if (outputPath) {
  fs.mkdirSync(path.dirname(path.resolve(outputPath)), { recursive: true });
  fs.writeFileSync(path.resolve(outputPath), `${text}\n`, "utf8");
} else {
  process.stdout.write(`${text}\n`);
}
